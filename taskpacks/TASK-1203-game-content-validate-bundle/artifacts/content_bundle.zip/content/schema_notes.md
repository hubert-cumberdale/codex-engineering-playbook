# Schema notes (human-readable)

This file exists to show how a game/content team might document rules
without requiring an external schema system.

Validation is implemented in `tools/validate_content.py` and is enforced by acceptance.
